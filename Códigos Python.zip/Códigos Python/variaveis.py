a = 15
b =20
soma = a + b
print("Resultado da soma:" + str(soma))