a = 100
b = 20

soma = a + b 
sub = a - b
div = a / b
mul = a * b

print("Resultado da soma:" + str(soma))
print("Resultado da subtração:" + str(sub))
print("Resultado da divisão:" + str(div))
print("Resultado da multiplicação:" + str(mul))

