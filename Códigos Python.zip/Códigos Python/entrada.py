name = input('Digite seu nome:')
idade = input('Digite sua idade:')
print('Olá,' + name + '. Você tem '+ idade +' anos.')
